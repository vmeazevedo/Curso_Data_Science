# timeseries
Curso de séries temporais: previsão
